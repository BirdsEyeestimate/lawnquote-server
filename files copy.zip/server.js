require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const nodemailer = require('nodemailer');
const app = express();

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' }));
app.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.post('/map-image', async (req, res) => {
  try {
    const { address } = req.body;
    const geo = await axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
      params: { address, key: process.env.GOOGLE_MAPS_KEY }
    });
    const { lat, lng } = geo.data.results[0].geometry.location;
    const img = await axios.get('https://maps.googleapis.com/maps/api/staticmap', {
      params: { center: `${lat},${lng}`, zoom: 19, size: '600x400', maptype: 'satellite', key: process.env.GOOGLE_MAPS_KEY },
      responseType: 'arraybuffer'
    });
    const b64 = Buffer.from(img.data).toString('base64');
    res.json({ image: b64, lat, lng });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/analyze', async (req, res) => {
  try {
    const { base64, mime, prompt } = req.body;
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: 'claude-opus-4-6',
      max_tokens: 500,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mime, data: base64 } },
          { type: 'text', text: prompt }
        ]
      }]
    }, {
      headers: {
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json'
      }
    });
    const raw = response.data.content.map(b => b.text || '').join('');
    const parsed = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json(parsed);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// Lead capture route
app.post('/lead', async (req, res) => {
  try {
    const { name, email, phone, address, sqft } = req.body;

    // Always log to console
    console.log('\n NEW LEAD');
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Phone:', phone);
    console.log('Address:', address);
    console.log('Sq ft:', sqft);
    console.log('Time:', new Date().toLocaleString());
    console.log('---');

    // Send email if SMTP credentials are configured in .env
    if (process.env.SMTP_USER && process.env.SMTP_PASS && process.env.NOTIFY_EMAIL) {
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      });
      await transporter.sendMail({
        from: process.env.SMTP_USER,
        to: process.env.NOTIFY_EMAIL,
        subject: `New LawnQuote lead - ${name}`,
        html: `
          <div style="font-family:sans-serif;max-width:480px">
            <h2 style="color:#27500A">New lawn quote request</h2>
            <table style="width:100%;border-collapse:collapse;font-size:15px">
              <tr><td style="padding:8px 0;color:#666;width:100px">Name</td><td style="padding:8px 0;font-weight:600">${name}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Email</td><td style="padding:8px 0">${email || '—'}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Phone</td><td style="padding:8px 0">${phone || '—'}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Address</td><td style="padding:8px 0">${address}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Lawn size</td><td style="padding:8px 0">${Number(sqft).toLocaleString()} sq ft</td></tr>
              <tr><td style="padding:8px 0;color:#666">Time</td><td style="padding:8px 0">${new Date().toLocaleString()}</td></tr>
            </table>
          </div>
        `
      });
    }

    res.json({ ok: true });
  } catch(err) {
    console.error('Lead error:', err.message);
    res.json({ ok: false });
  }
});

app.listen(3001, () => console.log('LawnQuote server running on http://localhost:3001'));
