require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');
const app = express();

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' }));
app.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname)));

const LEADS_FILE = path.join(__dirname, 'leads.json');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');

function readLeads() { try { return JSON.parse(fs.readFileSync(LEADS_FILE)); } catch(e) { return []; } }
function readSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS_FILE)); } catch(e) { return {}; } }

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'admin.html')));

app.post('/map-image', async (req, res) => {
  try {
    const { address } = req.body;
    const geo = await axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
      params: { address, key: process.env.GOOGLE_MAPS_KEY }
    });
    const { lat, lng } = geo.data.results[0].geometry.location;
    const img = await axios.get('https://maps.googleapis.com/maps/api/staticmap', {
      params: { center: `${lat},${lng}`, zoom: 19, size: '600x400', maptype: 'satellite', key: process.env.GOOGLE_MAPS_KEY },
      responseType: 'arraybuffer'
    });
    const b64 = Buffer.from(img.data).toString('base64');
    res.json({ image: b64, lat, lng });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/analyze', async (req, res) => {
  try {
    const { base64, mime, prompt } = req.body;
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: 'claude-opus-4-6',
      max_tokens: 500,
      messages: [{ role: 'user', content: [
        { type: 'image', source: { type: 'base64', media_type: mime, data: base64 } },
        { type: 'text', text: prompt }
      ]}]
    }, { headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json' } });
    const raw = response.data.content.map(b => b.text || '').join('');
    const parsed = JSON.parse(raw.replace(/```json|```/g, '').trim());
    res.json(parsed);
  } catch(err) { res.status(500).json({ error: err.message }); }
});

app.post('/lead', async (req, res) => {
  try {
    const { name, email, phone, address, sqft } = req.body;
    const lead = { name, email, phone, address, sqft, time: new Date().toLocaleString() };
    const leads = readLeads();
    leads.unshift(lead);
    fs.writeFileSync(LEADS_FILE, JSON.stringify(leads, null, 2));
    console.log('\n NEW LEAD:', name, email, phone, address, sqft);
    const settings = readSettings();
    if (settings.notifyEmail && process.env.SMTP_USER && process.env.SMTP_PASS) {
      const transporter = nodemailer.createTransport({ service: 'gmail', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
      await transporter.sendMail({ from: process.env.SMTP_USER, to: settings.notifyEmail, subject: `New lead - ${name}`, html: `<p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email}</p><p><b>Phone:</b> ${phone}</p><p><b>Address:</b> ${address}</p><p><b>Sq ft:</b> ${sqft}</p>` });
    }
    res.json({ ok: true });
  } catch(err) { res.json({ ok: false }); }
});

app.get('/leads', (req, res) => res.json(readLeads()));

app.post('/settings', (req, res) => {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(req.body, null, 2));
    res.json({ ok: true });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

app.get('/settings', (req, res) => res.json(readSettings()));


const fs = require('fs');
const SETTINGS_FILE = './settings.json';
const LEADS_FILE = './leads.json';

app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'admin.html')));

app.post('/settings', (req, res) => {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(req.body, null, 2));
    res.json({ ok: true });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/settings', (req, res) => {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      res.json(JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')));
    } else {
      res.json({});
    }
  } catch(err) {
    res.json({});
  }
});

app.get('/leads', (req, res) => {
  try {
    if (fs.existsSync(LEADS_FILE)) {
      res.json(JSON.parse(fs.readFileSync(LEADS_FILE, 'utf8')));
    } else {
      res.json([]);
    }
  } catch(err) {
    res.json([]);
  }
});

app.listen(3001, () => console.log('LawnQuote server running on http://localhost:3001'));
